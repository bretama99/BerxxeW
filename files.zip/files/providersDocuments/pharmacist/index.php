<?php
header("location:../../../apps/dashboard/index.php?name=hub/analytics/analytics&var=analytics");
